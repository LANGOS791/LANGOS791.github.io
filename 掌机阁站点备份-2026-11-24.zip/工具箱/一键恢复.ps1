﻿param(
  [string]$Target = 'D:\掌机阁资源库'
)

$ErrorActionPreference = 'Stop'
$Base = 'https://raw.githubusercontent.com/LANGOS791/LANGOS791.github.io/main'
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'

Write-Host '----------------------------------------'
Write-Host ' 掌机阁资源库 - 一键恢复'
Write-Host '----------------------------------------'

if (-not (Test-Path -LiteralPath $Target)) {
  New-Item -ItemType Directory -Force -Path $Target | Out-Null
}

$BakDir = Join-Path $Target "备份\自动备份-$Stamp"
New-Item -ItemType Directory -Force -Path $BakDir | Out-Null

$files = @('index.html', 'donate.png')
foreach ($name in $files) {
  $dest = Join-Path $Target $name
  if (Test-Path -LiteralPath $dest) {
    Copy-Item -LiteralPath $dest -Destination (Join-Path $BakDir $name) -Force
    Write-Host "已备份旧 $name"
  }
  $url = "$Base/$name" + "?v=$Stamp"
  Write-Host "正在下载 $name ..."
  Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -TimeoutSec 90
  $size = (Get-Item -LiteralPath $dest).Length
  Write-Host "OK  $name  ($size 字节)"
}

Write-Host ''
Write-Host "恢复完成：$Target"
Write-Host "旧文件已备份到：$BakDir"
Write-Host ''
Write-Host '即将用浏览器打开本地页面，请检查分类、条目和捐赠二维码。'
Start-Sleep -Seconds 1

$html = Join-Path $Target 'index.html'
if (Test-Path -LiteralPath $html) {
  Start-Process $html
}
