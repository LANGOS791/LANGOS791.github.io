@echo off
chcp 65001 >nul
title Zhangjige Restore
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0一键恢复.ps1" -Target "D:\掌机阁资源库"
echo.
echo 如出现红色错误，请检查网络后重新双击本文件。
pause